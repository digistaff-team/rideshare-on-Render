import asyncio
import logging
from datetime import datetime, timedelta
from sqlalchemy import delete, select
from aiogram import Router, types, F
from aiogram.filters import Command, StateFilter
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from src.database.session import async_session
from src.database.models import User, Ride
from src.services.nlu import NLUProcessor

logger = logging.getLogger(__name__)
router = Router()
nlu = NLUProcessor()

class RideForm(StatesGroup):
    chatting_with_ai = State()

def main_kb():
    kb = [
        [KeyboardButton(text="🙋 Подвези"), KeyboardButton(text="🚗 Подвезу")],
        [KeyboardButton(text="🔍 Найти попутчиков")],
        [KeyboardButton(text="📋 Мои поездки")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

# --- ФОНОВАЯ ОЧИСТКА (Теперь на месте) ---
async def auto_clean_old_rides():
    """Фоновая задача для удаления поездок старше 2 дней."""
    while True:
        try:
            async with async_session() as session:
                limit = datetime.utcnow() - timedelta(days=2)
                await session.execute(delete(Ride).where(Ride.created_at < limit))
                await session.commit()
                logger.info("Очистка базы завершена.")
            await asyncio.sleep(43200) # Раз в 12 часов
        except Exception as e:
            logger.error(f"Ошибка очистки: {e}")
            await asyncio.sleep(3600)

# --- ОБРАБОТЧИКИ ---

@router.message(Command("start"), StateFilter("*"))
async def start(m: types.Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == m.from_user.id))
        if not result.scalar():
            session.add(User(telegram_id=m.from_user.id, username=m.from_user.username))
            await session.commit()
    await m.answer("Привет! Я помогу найти попутчиков. Выберите роль:", reply_markup=main_kb())

@router.message(F.text.in_(["🙋 Подвези", "🚗 Подвезу"]), StateFilter("*"))
async def ask_route(m: types.Message, state: FSMContext):
    await state.clear()
    role = "passenger" if "🙋" in m.text else "driver"
    # Инициализируем данные в состоянии
    await state.update_data(role=role, origin=None, destination=None, date=None, time=None, seats=1)
    await state.set_state(RideForm.chatting_with_ai)
    
    text = ("Напишите, откуда и куда вы едете, и дату. Например: 'Из Краснодара в Москву завтра'" if role == "passenger" 
            else "Напишите детали поездки: маршрут, дату и сколько мест есть.")
    await m.answer(text)

@router.message(RideForm.chatting_with_ai)
async def handle_ai_conversation(m: types.Message, state: FSMContext):
    if m.text and m.text.startswith("/"): return

    res = await nlu.parse_intent(m.text, m.from_user.id)
    if not res:
        return await m.answer("Извините, не удалось обработать сообщение. Попробуйте еще раз.")

    # Получаем текущие данные и обновляем их тем, что нашел ИИ
    current_data = await state.get_data()
    updated_fields = {}
    for key in ['origin', 'destination', 'date', 'seats']:
        if res.get(key):
            updated_fields[key] = res[key]
    
    time_val = res.get('time') or res.get('start_time')
    if time_val:
        updated_fields['time'] = time_val

    await state.update_data(**updated_fields)
    new_full_data = await state.get_data()

    # Проверка обязательных полей
    if new_full_data.get('origin') and new_full_data.get('destination') and new_full_data.get('date'):
        await process_ride_data(m, new_full_data, state)
        ai_reply = res.get("raw_text")
        if not ai_reply or ai_reply.strip().startswith("{"):
            ai_reply = "Отлично! Ваша поездка сохранена."
        await m.answer(ai_reply)
    else:
        # Уточнение данных
        ai_reply = res.get("raw_text")
        if not ai_reply or ai_reply.strip().startswith("{"):
            missing = []
            if not new_full_data.get('origin'): missing.append("откуда")
            if not new_full_data.get('destination'): missing.append("куда")
            if not new_full_data.get('date'): missing.append("дату")
            ai_reply = f"Пожалуйста, уточните {', '.join(missing)} вашей поездки."
        await m.answer(ai_reply)

async def process_ride_data(m: types.Message, data: dict, state: FSMContext):
    async with async_session() as s:
        user_res = await s.execute(select(User).where(User.telegram_id == m.from_user.id))
        user = user_res.scalar()
        if not user: return

        new_ride = Ride(
            user_id=user.id,
            origin=data.get('origin'),
            destination=data.get('destination'),
            ride_date=data.get('date'),
            start_time=data.get('time', 'Не указано'),
            seats=int(data.get('seats', 1)) if str(data.get('seats', '')).isdigit() else 1,
            role=data.get('role', 'passenger')
        )
        s.add(new_ride)
        await s.commit()
    
    await state.clear()
    await m.answer("✅ Поездка успешно опубликована!", reply_markup=main_kb())

@router.message(F.text == "📋 Мои поездки", StateFilter("*"))
async def show_my_rides(m: types.Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        user_res = await session.execute(select(User).where(User.telegram_id == m.from_user.id))
        user = user_res.scalar()
        if not user: return await m.answer("Сначала нажмите /start.")

        rides_res = await session.execute(select(Ride).where(Ride.user_id == user.id).order_by(Ride.created_at.desc()))
        rides = rides_res.scalars().all()

        if not rides: return await m.answer("У вас пока нет активных поездок.")

        await m.answer("📋 **Ваши поездки:**", parse_mode="Markdown")
        for ride in rides:
            icon = "🚗" if ride.role == "driver" else "🙋"
            ride_text = f"{icon} **{ride.origin} → {ride.destination}**\n📅 {ride.ride_date} | ⏰ {ride.start_time}\n💺 Мест: {ride.seats}"
            builder = InlineKeyboardBuilder()
            builder.button(text="❌ Удалить", callback_data=f"delete_{ride.id}")
            await m.answer(ride_text, reply_markup=builder.as_markup(), parse_mode="Markdown")

@router.message(F.text == "🔍 Найти попутчиков", StateFilter("*"))
async def find_all_rides(m: types.Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        query = select(Ride, User).join(User, Ride.user_id == User.id).where(User.telegram_id != m.from_user.id).order_by(Ride.created_at.desc()).limit(10)
        result = await session.execute(query)
        rides_data = result.all()

        if not rides_data: return await m.answer("🔍 Пока объявлений от других пользователей нет.")

        await m.answer("🔍 **Актуальные предложения:**", parse_mode="Markdown")
        for ride, user in rides_data:
            role_icon = "🚗 Водитель" if ride.role == "driver" else "🙋 Пассажир"
            contact = f"@{user.username}" if user.username else f"[Написать](tg://user?id={user.telegram_id})"
            text = f"{role_icon}\n📍 **{ride.origin} → {ride.destination}**\n📅 {ride.ride_date} | ⏰ {ride.start_time}\n💺 Мест: {ride.seats}\n👤 Контакт: {contact}"
            await m.answer(text, parse_mode="Markdown", disable_web_page_preview=True)

@router.callback_query(F.data.startswith("delete_"))
async def delete_ride_handler(callback: types.CallbackQuery):
    ride_id = int(callback.data.split("_")[1])
    async with async_session() as session:
        await session.execute(delete(Ride).where(Ride.id == ride_id))
        await session.commit()
    await callback.message.edit_text("🗑 Поездка удалена.")
    await callback.answer("Удалено")