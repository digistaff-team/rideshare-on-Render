from sqlalchemy import Column, Integer, String, BigInteger, ForeignKey, DateTime, Text
from sqlalchemy.orm import relationship, declarative_base
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Связь с поездками
    rides = relationship("Ride", back_populates="user", cascade="all, delete-orphan")

class Ride(Base):
    __tablename__ = "rides"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    
    # Данные маршрута
    origin = Column(String(255), nullable=False)      # Откуда
    destination = Column(String(255), nullable=False) # Куда
     
     # Число мест
    seats = Column(Integer, default=1)
    
    # Время и дата (добавлены по итогам отладки Pro-Talk)
    ride_date = Column(String(100), nullable=True)    # Поле для хранения даты (напр. "28 декабря")
    start_time = Column(String(100), nullable=True)   # Поле для хранения времени (напр. "10:00")
    
    role = Column(String(50))                         # driver или passenger
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="rides")
