import asyncio
from src.database.session import engine
from src.database.models import Base, User, Ride 

async def init_models():
    async with engine.begin() as conn:
        print("Очистка старых таблиц...")
        await conn.run_sync(Base.metadata.drop_all)
        print("Создание новых таблиц...")
        await conn.run_sync(Base.metadata.create_all)
    print("Готово! Проверьте список таблиц командой \dt")

if __name__ == "__main__":
    asyncio.run(init_models())
