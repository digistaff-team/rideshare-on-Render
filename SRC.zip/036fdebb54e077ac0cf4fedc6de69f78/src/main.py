import asyncio
import os
import logging
import sys
from contextlib import asynccontextmanager
from aiogram import Bot, Dispatcher
from fastapi import FastAPI
from dotenv import load_dotenv

from src.bot.handlers import router, auto_clean_old_rides
from src.database.session import init_models

# Загружаем переменные окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stdout
)
logger = logging.getLogger("src.main")

# Глобальные объекты (инициализируем позже)
dp = Dispatcher()
dp.include_router(router)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Проверка токена
    token = os.getenv("BOT_TOKEN")
    if not token:
        logger.critical("❌ BOT_TOKEN не найден в .env!")
        raise ValueError("BOT_TOKEN is missing")

    # 2. Инициализация бота внутри контекста
    bot = Bot(token=token)
    app.state.bot = bot # Сохраняем в состояние FastAPI, если понадобится

    logger.info("🚀 Инициализация моделей базы данных...")
    await init_models()
    
    logger.info("🔄 Запуск фоновых задач...")
    # Фоновая очистка
    t1 = asyncio.create_task(auto_clean_old_rides())
    # Запуск бота (Polling)
    t2 = asyncio.create_task(dp.start_polling(bot, skip_updates=False))
    
    yield
    
    logger.info("🛑 Остановка бота и фоновых задач...")
    t2.cancel()
    t1.cancel()
    try:
        await asyncio.gather(t1, t2, return_exceptions=True)
    except Exception as e:
        logger.error(f"Ошибка при закрытии задач: {e}")
    
    await bot.session.close()
    logger.info("✅ Сессия бота закрыта.")

# Создаем приложение FastAPI
app = FastAPI(lifespan=lifespan)

# Блок для прямого запуска через python3 -m src.main или python3 src/main.py
if __name__ == "__main__":
    import uvicorn
    logger.info("Запуск приложения через Uvicorn...")
    uvicorn.run(app, host="0.0.0.0", port=8000)
