import asyncio
import logging
import json
import re
from datetime import datetime, timedelta
from sqlalchemy import delete, select
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from src.database.session import async_session
from src.database.models import User, Ride
from src.services.nlu import NLUProcessor

logger = logging.getLogger(__name__)
router = Router()
nlu = NLUProcessor()

class RideForm(StatesGroup):
    chatting_with_ai = State()

def main_kb():
    kb = [
        [KeyboardButton(text="🙋 Подвези"), KeyboardButton(text="🚗 Подвезу")],
        [KeyboardButton(text="📋 Мои поездки")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

# --- ФОНОВЫЕ ЗАДАЧИ ---
async def auto_clean_old_rides():
    """Фоновая задача для очистки старых поездок (старше 2 дней)"""
    while True:
        try:
            async with async_session() as session:
                limit = datetime.utcnow() - timedelta(days=2)
                await session.execute(delete(Ride).where(Ride.created_at < limit))
                await session.commit()
                logger.info("Фоновая очистка базы завершена успешно.")
            await asyncio.sleep(43200)  # Раз в 12 часов
        except Exception as e:
            logger.error(f"Ошибка фоновой очистки: {e}")
            await asyncio.sleep(3600)

# --- ПРИВЕТСТВИЕ ---
@router.message(Command("start"))
async def start(m: types.Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == m.from_user.id))
        if not result.scalar():
            session.add(User(telegram_id=m.from_user.id, username=m.from_user.username))
            await session.commit()
    
    welcome_text = (
        "Привет! Я помогу найти попутчиков.\n\n"
        "Если вы пассажир — нажмите **🙋 Подвези**\n"
        "Если вы водитель — нажмите **🚗 Подвезу**"
    )
    await m.answer(welcome_text, reply_markup=main_kb(), parse_mode="Markdown")

# --- ВЫБОР РОЛИ ---
@router.message(F.text.in_(["🙋 Подвези", "🚗 Подвезу"]))
async def ask_route(m: types.Message, state: FSMContext):
    role = "passenger" if "🙋" in m.text else "driver"
    await state.update_data(role=role)
    await state.set_state(RideForm.chatting_with_ai)
    
    text = (
        "Напишите маршрут поездки, например: *'Из Здравого в Краснодар завтра в 9 утра'*."
        if role == "passenger" else
        "Напишите детали: *'Еду из Краснодара в Здравое 27.12 в 18:00, есть 3 места'*."
    )
    await m.answer(text, parse_mode="Markdown")

# --- ГЛАВНЫЙ ОБРАБОТЧИК ДИАЛОГА (Исправлено для свободного общения) ---
@router.message(RideForm.chatting_with_ai)
@router.message(F.text & ~F.text.startswith("/"))
async def handle_ai_conversation(m: types.Message, state: FSMContext):
    res = await nlu.parse_intent(m.text, m.from_user.id)
    
    if not res:
        return await m.answer("Извините, сервис временно недоступен.")

    # 1. Если ИИ собрал полные данные (JSON) — сохраняем поездку
    # Проверяем наличие всех ключевых полей, чтобы не сохранять пустые анкеты
    if res.get("origin") and res.get("destination") and res.get("date"):
        await process_ride_data(m, res, state)
    
    # 2. Выводим текстовый ответ от ИИ (болтовня, уточнение или подтверждение)
    # Мы больше не выводим стандартную заглушку, а даем слово ИИ
    ai_reply = res.get("raw_text")
    if ai_reply:
        await m.answer(ai_reply)
    elif not res.get("origin"):
        # Резервный ответ, если NLU вернул абсолютно пустой объект
        await m.answer("Я вас не совсем понял. Уточните, пожалуйста, откуда и куда вы едете?")

async def process_ride_data(m: types.Message, res: dict, state: FSMContext):
    data = await state.get_data()
    role = data.get('role', 'passenger')
    
    async with async_session() as s:
        user_stmt = await s.execute(select(User).where(User.telegram_id == m.from_user.id))
        user = user_stmt.scalar()
        if not user: return

        new_ride = Ride(
            user_id=user.id,
            origin=res['origin'],
            destination=res['destination'],
            ride_date=res['date'],
            start_time=res.get('start_time', 'Не указано'),
            seats=int(res.get('seats', 1)),
            role=role
        )
        s.add(new_ride)
        await s.commit()
        await s.refresh(new_ride)

        await m.answer(f"✅ Поездка сохранена!", reply_markup=main_kb())

        # Поиск совпадений
        target_role = "driver" if role == "passenger" else "passenger"
        matches_stmt = await s.execute(
            select(User.telegram_id, Ride).join(Ride).where(
                Ride.origin.ilike(f"%{res['origin']}%"),
                Ride.destination.ilike(f"%{res['destination']}%"),
                Ride.ride_date == res['date'],
                Ride.role == target_role,
                User.id != user.id
            )
        )

        for tid, r_obj in matches_stmt.all():
            is_current_user_driver = (role == "driver")
            driver_tid = m.from_user.id if is_current_user_driver else tid
            passenger_tid = tid if is_current_user_driver else m.from_user.id
            
            kb = InlineKeyboardBuilder()
            kb.button(text="🤝 Взять попутчика", callback_data=f"acc_{new_ride.id}_{passenger_tid}")
            
            match_msg = (
                f"🔔 *Найден попутчик!*\n"
                f"📍 {res['origin']} ➡️ {res['destination']}\n"
                f"📅 Дата: {res['date']}\n"
                f"👤 Контакт: @{m.from_user.username or 'скрыт'}"
            )
            try:
                await m.bot.send_message(driver_tid, match_msg, reply_markup=kb.as_markup(), parse_mode="Markdown")
            except Exception as e:
                logger.error(f"Ошибка уведомления {driver_tid}: {e}")

    await state.clear()

# --- КНОПКИ МОИ ПОЕЗДКИ ---
@router.message(F.text == "📋 Мои поездки")
async def list_rides(m: types.Message):
    async with async_session() as s:
        user_stmt = await s.execute(select(User.id).where(User.telegram_id == m.from_user.id))
        u_id = user_stmt.scalar()
        rides_stmt = await s.execute(select(Ride).where(Ride.user_id == u_id))
        rides = rides_stmt.scalars().all()
        
        if not rides:
            return await m.answer("У вас пока нет активных поездок.")
        
        for r in rides:
            txt = f"📍 {r.origin} -> {r.destination}\n📅 {r.ride_date} | {r.start_time}"
            kb = InlineKeyboardBuilder().button(text="❌ Удалить", callback_data=f"del_{r.id}").as_markup()
            await m.answer(txt, reply_markup=kb)

# --- CALLBACKS ---
@router.callback_query(F.data.startswith("acc_"))
async def accept_ride(cb: types.CallbackQuery):
    _, r_id, p_tid = cb.data.split("_")
    await cb.bot.send_message(int(p_tid), f"🎉 Водитель @{cb.from_user.username} подтвердил вашу поездку!")
    await cb.answer("Пассажир уведомлен!", show_alert=True)
    await cb.message.edit_text(cb.message.text + "\n\n✅ Подтверждено")

@router.callback_query(F.data.startswith("del_"))
async def delete_ride(cb: types.CallbackQuery):
    r_id = int(cb.data.split("_")[1])
    async with async_session() as s:
        ride = await s.get(Ride, r_id)
        if ride:
            await s.delete(ride)
            await s.commit()
            await cb.answer("Поездка удалена")
            await cb.message.delete()